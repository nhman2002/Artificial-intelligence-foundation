from enum import Enum

class Definition(Enum):
    EMPTY_CLAUSE = '{}'
    NOT_OPERATOR = '-'
    OR_OPERATOR = ' OR '
